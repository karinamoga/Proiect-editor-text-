#include "text_editor.h"
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

TextEditor *create_table(const char *filename, const char *text,
                         int global_cursor) {
  // TODO: Implement this function
  return NULL;
}

void advance_cursor(TextEditor *editor, int advance) {
  // TODO: Implement this function
}

int show_global_cursor(TextEditor *editor) {
  // TODO: Implement this function
  return 0;
}

int show_total_len(TextEditor *editor) {
  // TODO: Implement this function
  return 0;
}

void add_text(TextEditor *editor, char *text) {
  // TODO: Implement this function
}

void delete_text(TextEditor *editor, int length) {
  // TODO: Implement this function
}

char *extract_current_text(TextEditor *editor) {
  // TODO: Implement this function
  return NULL;
}

void save_current_text(TextEditor *editor, const char *filename, 
                       char **text, int *global_cursor) {
  // TODO: Implement this function
}
